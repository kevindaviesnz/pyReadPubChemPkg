

from settings import SettingsProvider
print(SettingsProvider.LOG_LEVEL)